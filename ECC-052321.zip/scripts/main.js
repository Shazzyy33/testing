$(document).ready(() => {
    $('.home-banner').slick({
        autoplay: true,
        autoplaySpeed: 4000,
        arrows: false,
        dots: true,
        fade: true,
        speed: 1800,
        pauseOnHover: false,
        pauseOnFocus: false,
    });
});
